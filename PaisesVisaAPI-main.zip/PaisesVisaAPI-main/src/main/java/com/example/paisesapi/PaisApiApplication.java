package com.example.paisesapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaisApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaisApiApplication.class, args);
    }
}