package com.example.paisesapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaisesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaisesApiApplication.class, args);
	}

}
